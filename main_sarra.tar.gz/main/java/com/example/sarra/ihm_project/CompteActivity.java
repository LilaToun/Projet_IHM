package com.example.sarra.ihm_project;

import android.app.Activity;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;

import org.w3c.dom.Text;

/**
 * Created by sarra on 15/04/17.
 */

public class CompteActivity extends Activity{

    private String titulaire ="toto";
    private String num = "123456789";
    private String crypto = "123";
    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.compte);
        final Button login = (Button) findViewById(R.id.valideNewCompte);
        login.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                EditText nom = (EditText) findViewById(R.id.newName);
                EditText prenom = (EditText) findViewById(R.id.newPrenom);
                EditText pseudo = (EditText) findViewById(R.id.newPseudo);
                EditText num = (EditText) findViewById(R.id.newNum);
                EditText tit = (EditText) findViewById(R.id.titulaire);
                EditText crypto = (EditText) findViewById(R.id.crypto);
                Intent in ;
                //verifie que tous les champs sont rempli
                if(! (isValide(nom.getText().toString(),prenom.getText().toString(),
                        pseudo.getText().toString(),tit.getText().toString(),
                        num.getText().toString(),crypto.getText().toString()))) {
                    TextView err = (TextView) findViewById(R.id.errorCompte);
                    err.setText("Votre mot de passe ou votre identifiant n'est pas reconnu");

                }
                else{
                    //verifie que pseudo n'est pas deja existant
                    if(Users.add(pseudo.getText().toString(),new Profile(nom.getText().toString(),
                            prenom.getText().toString(),pseudo.getText().toString(),
                            tit.getText().toString(),num.getText().toString(),crypto.getText().toString()))) {
                        in = new Intent(CompteActivity.this, ProfileActivity.class);
                        startActivity(in);
                    }
                    else{

                        TextView err = (TextView) findViewById(R.id.errorCompte);
                        err.setText("Votre mot de passe ou votre identifiant n'est pas reconnu");
                    }
                }


            }
        });
    }
    // not use
    public boolean cBValide(String titulaire, String num, String crypto){
        if(this.titulaire.equals(titulaire) && this.num.equals(num) && this.crypto.equals(crypto))
            return true;
        return false;
    }
    //use
    public boolean isValide(String nom, String prenom, String pseudo,String titulaire, String num, String crypto){
        if(nom.equals("")||prenom.equals("") || pseudo.equals("") ||titulaire.equals("") ||num.equals("")||crypto.equals("") )
            return false;
        return true;

    }
}
