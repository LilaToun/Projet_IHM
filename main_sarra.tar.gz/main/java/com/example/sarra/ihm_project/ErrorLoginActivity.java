package com.example.sarra.ihm_project;

import android.app.Activity;
import android.os.Bundle;

/**
 * Created by sarra on 17/04/17.
 */

public class ErrorLoginActivity extends Activity{
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.error);
    }
}
