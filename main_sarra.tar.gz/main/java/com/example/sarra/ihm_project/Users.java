package com.example.sarra.ihm_project;

import java.util.HashMap;

/**
 * Created by sarra on 17/04/17.
 */

public class Users {
    private static HashMap<String,Profile> users = new HashMap<>();
    public static boolean add(String pseudo, Profile p){
        if(users.containsKey(pseudo))
            return false;
        else{
            users.put(pseudo,p);
            return true;
        }
    }
}
