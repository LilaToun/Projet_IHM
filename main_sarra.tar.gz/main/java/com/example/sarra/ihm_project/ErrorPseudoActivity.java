package com.example.sarra.ihm_project;

import android.app.Activity;

/**
 * Created by sarra on 17/04/17.
 */

public class ErrorPseudoActivity extends Activity {
}
