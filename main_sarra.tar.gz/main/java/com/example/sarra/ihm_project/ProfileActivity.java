package com.example.sarra.ihm_project;

import android.app.Activity;
import android.os.Bundle;

/**
 * Created by sarra on 17/04/17.
 */

public class ProfileActivity extends Activity {
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.profile);
    }
}
